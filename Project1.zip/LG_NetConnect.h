#pragma once
class CLG_NetConnect
{
public:


protected:



private:






};