#include "LinkGamgeMainWnd.h"

CLinkGameMainWnd::CLinkGameMainWnd()
{
	m_pNotify = 0;
}

CLinkGameMainWnd::~CLinkGameMainWnd()
{
}

void CLinkGameMainWnd::SetWindowInformation(LGMainWndInfoSt * pInfo)
{
}

void CLinkGameMainWnd::CreatLinkGameWnd()
{
}

void CLinkGameMainWnd::SetNotifyCallBack()
{
}
