#pragma once




class CLinkGameBlock
{
public:


protected:


private:




};
